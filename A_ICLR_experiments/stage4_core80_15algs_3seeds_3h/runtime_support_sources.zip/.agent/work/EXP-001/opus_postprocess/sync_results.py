from __future__ import annotations

import csv
import fcntl
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[4]
WORK = Path(__file__).resolve().parent
BATCH = "stage4_core80_all_20260922"
LOCAL_EXPERIMENTS = ROOT / "A_ICLR_experiments/stage4_core80_15algs_3seeds_3h/2、experiments"
STAGING = WORK / "synced"
REPORT = WORK / "sync_report.json"
LOCK = WORK / ".sync.lock"
SOURCE_CSV = ROOT / ".agent/work/EXP-001/controller/core80_source.csv"
QUEUE_STATE = ROOT / ".agent/work/EXP-001/controller/queue/state/stage4_core80_all_20260922.state.json"

REMOTE_ROOTS = {
    "iaaccn22": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn23": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn24": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn25": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn26": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn27": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn28": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn29": "/home/zhangziwen/workplace/scientific-intelligent-modelling",
    "iaaccn48": "/data1/zhangziwen/sim-runtime/code",
    "iaaccn49": "/data3/zhangziwen/sim-runtime/code",
    "iaaccn50": "/data1/zhangziwen/sim-runtime/code",
    "iaaccn51": "/data1/zhangziwen/sim-runtime/code",
    "iaaccn52": "/data1/zhangziwen/sim-runtime/code",
    "iaaccn53": "/data1/zhangziwen/sim-runtime/code",
    "iaaccn55": "/data1/zhangziwen/sim-runtime/code",
}
TASK_RE = re.compile(r"^(?P<algorithm>[a-z0-9]+)_s(?P<seed>520|521|522)_(?P<condition>clean|noise001|noise005)_g(?P<index>\d{4})$")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def load_source_rows() -> dict[int, dict[str, str]]:
    with SOURCE_CSV.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return {int(row["global_index"]): row for row in rows}


def load_queue_state() -> dict[str, Any]:
    if not QUEUE_STATE.is_file():
        return {"tasks": {}}
    return json.loads(QUEUE_STATE.read_text(encoding="utf-8"))


def result_file_list(host: str, source_rows: dict[int, dict[str, str]], queue_state: dict[str, Any]) -> list[str]:
    paths: list[str] = []
    for task_id, task in queue_state.get("tasks", {}).items():
        if task.get("assigned_host") != host or task.get("state") not in {"done", "running"}:
            continue
        match = TASK_RE.fullmatch(str(task_id))
        if match is None:
            continue
        global_index = int(match.group("index"))
        source_row = source_rows.get(global_index)
        if source_row is None:
            continue
        algorithm = match.group("algorithm")
        runtime_tool = {"imcts": "iMCTS", "qlattice": "QLattice"}.get(algorithm, algorithm)
        seed = match.group("seed")
        dataset_name = source_row["dataset_name"]
        task_host = str(task.get("assigned_host"))
        label = f"g{global_index:04d}_{dataset_name}"
        paths.append(
            f"{algorithm}/seed{seed}/tasks/{task_id}/{task_host}/{runtime_tool}/{label}/result.json"
        )
    return sorted(set(paths))


def sync_host(
    host: str,
    source_rows: dict[int, dict[str, str]],
    queue_state: dict[str, Any],
) -> dict[str, Any]:
    destination = STAGING / host
    destination.mkdir(parents=True, exist_ok=True)
    remote = f"{host}:{REMOTE_ROOTS[host]}/experiments/{BATCH}/"
    files = result_file_list(host, source_rows, queue_state)
    if not files:
        return {"host": host, "status": "ok", "attempt": 0, "requested_files": 0}
    ssh_command = (
        "ssh -o BatchMode=yes -o ConnectTimeout=10 "
        "-o ServerAliveInterval=10 -o ServerAliveCountMax=2"
    )
    command = [
        "rsync",
        "-a",
        "--timeout=30",
        "-e",
        ssh_command,
        "--files-from=-",
        remote,
        str(destination),
    ]
    last_error = ""
    for attempt in range(1, 6):
        completed = subprocess.run(
            command,
            cwd=ROOT,
            input="\n".join(files) + "\n",
            text=True,
            capture_output=True,
            check=False,
            timeout=240,
        )
        if completed.returncode == 0:
            return {
                "host": host,
                "status": "ok",
                "attempt": attempt,
                "requested_files": len(files),
                "stdout_tail": completed.stdout[-500:],
                "stderr_tail": completed.stderr[-500:],
            }
        if completed.returncode == 23:
            return {
                "host": host,
                "status": "partial",
                "attempt": attempt,
                "requested_files": len(files),
                "stdout_tail": completed.stdout[-500:],
                "stderr_tail": completed.stderr[-500:],
            }
        last_error = (completed.stderr or completed.stdout)[-1200:]
        time.sleep(min(30, 2 * attempt))
    return {
        "host": host,
        "status": "error",
        "attempt": 5,
        "requested_files": len(files),
        "error": last_error,
    }


def parse_candidate(path: Path, source_rows: dict[int, dict[str, str]]) -> dict[str, Any] | None:
    relative = path.relative_to(STAGING)
    parts = relative.parts
    try:
        tasks_index = parts.index("tasks")
    except ValueError:
        return None
    tail = parts[tasks_index + 1 :]
    if len(tail) != 5 or tail[-1] != "result.json":
        return None
    task_id, task_host, algorithm, task_label, _ = tail
    match = TASK_RE.fullmatch(task_id)
    if match is None or task_host != relative.parts[0] or algorithm.lower() != match.group("algorithm"):
        return None
    global_index = int(match.group("index"))
    source_row = source_rows.get(global_index)
    if source_row is None:
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    dataset_name = source_row["dataset_name"]
    if payload.get("task_global_index") not in {None, global_index}:
        return None
    if payload.get("dataset") not in {None, dataset_name}:
        return None
    if payload.get("feature_names") is not None and not isinstance(payload.get("feature_names"), list):
        return None
    return {
        "path": path,
        "host": relative.parts[0],
        "task_id": task_id,
        "task_host": task_host,
        "algorithm": algorithm,
        "seed": int(match.group("seed")),
        "condition": match.group("condition"),
        "global_index": global_index,
        "dataset_name": dataset_name,
        "task_label": task_label,
        "payload": payload,
        "result_sha256": sha256_file(path),
    }


def copy_file_atomic(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file():
        source_stat = source.stat()
        destination_stat = destination.stat()
        if (
            source_stat.st_size == destination_stat.st_size
            and source_stat.st_mtime_ns == destination_stat.st_mtime_ns
        ):
            return
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    shutil.copy2(source, temporary)
    temporary.replace(destination)


def copy_json_tree(source: Path, destination: Path) -> int:
    if not source.is_dir():
        return 0
    copied = 0
    for item in source.rglob("*.json"):
        relative = item.relative_to(source)
        target = destination / relative
        copy_file_atomic(item, target)
        copied += 1
    return copied


def normalize_results() -> dict[str, Any]:
    source_rows = load_source_rows()
    queue_state = load_queue_state()
    candidates_by_task: dict[str, list[dict[str, Any]]] = {}
    for path in STAGING.glob("*/**/result.json"):
        candidate = parse_candidate(path, source_rows)
        if candidate is not None:
            candidates_by_task.setdefault(candidate["task_id"], []).append(candidate)

    selected: list[dict[str, Any]] = []
    duplicate_tasks = 0
    for task_id, candidates in sorted(candidates_by_task.items()):
        preferred_host = str(queue_state.get("tasks", {}).get(task_id, {}).get("assigned_host") or "")
        candidates.sort(
            key=lambda item: (
                item["host"] == preferred_host,
                str(item["payload"].get("finished_at") or ""),
                str(item["path"]),
            ),
            reverse=True,
        )
        if len(candidates) > 1:
            duplicate_tasks += 1
        selected.append(candidates[0])

    copied = 0
    progress_copied = 0
    index_rows: list[dict[str, Any]] = []
    for candidate in selected:
        target_dir = (
            LOCAL_EXPERIMENTS
            / candidate["algorithm"]
            / candidate["dataset_name"]
            / candidate["condition"]
            / str(candidate["seed"])
        )
        result_target = target_dir / "result.json"
        override = queue_state['tasks'][candidate['task_id']].get('recovered_result_path')
        if override:
            recovered = Path(override)
            expected_sha = queue_state['tasks'][candidate['task_id']]['recovered_result_sha256']
            if sha256_file(recovered) != expected_sha:
                raise RuntimeError(f'recovered result hash mismatch: {recovered}')
            candidate = {**candidate, 'path': recovered, 'result_sha256': expected_sha}
        if not result_target.is_file() or sha256_file(result_target) != candidate["result_sha256"]:
            copy_file_atomic(candidate["path"], result_target)
            copied += 1
        source_root = candidate["path"].parent
        progress_copied += copy_json_tree(source_root / "progress", target_dir / "progress")
        progress_copied += copy_json_tree(source_root / "snapshots", target_dir / "snapshots")
        provenance = {
            "schema_version": "stage4.local_result_provenance.v1",
            "batch": BATCH,
            "task_id": candidate["task_id"],
            "algorithm": candidate["algorithm"],
            "dataset_name": candidate["dataset_name"],
            "global_index": candidate["global_index"],
            "condition": candidate["condition"],
            "seed": candidate["seed"],
            "source_host": candidate["host"],
            "source_path": str(candidate["path"]),
            "source_result_sha256": candidate["result_sha256"],
            "synced_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        atomic_write(target_dir / "provenance.json", provenance)
        index_rows.append(provenance)

    report = {
        "schema_version": "stage4.opus_sync.v1",
        "batch": BATCH,
        "synced_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "candidate_task_count": len(candidates_by_task),
        "selected_task_count": len(selected),
        "duplicate_task_count": duplicate_tasks,
        "result_files_copied": copied,
        "progress_files_copied": progress_copied,
        "hosts": sorted(REMOTE_ROOTS),
        "selected": index_rows,
    }
    atomic_write(REPORT, report)
    return report


def run_once() -> int:
    WORK.mkdir(parents=True, exist_ok=True)
    with LOCK.open("w", encoding="utf-8") as handle:
        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("sync_locked", flush=True)
            return 0
        source_rows = load_source_rows()
        queue_state = load_queue_state()
        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = [
                executor.submit(sync_host, host, source_rows, queue_state)
                for host in REMOTE_ROOTS
            ]
            host_reports = [future.result() for future in as_completed(futures)]
        report = normalize_results()
        report["host_sync"] = sorted(host_reports, key=lambda item: item["host"])
        atomic_write(REPORT, report)
        print(
            json.dumps(
                {
                    "selected_task_count": report["selected_task_count"],
                    "result_files_copied": report["result_files_copied"],
                    "progress_files_copied": report["progress_files_copied"],
                    "host_errors": sum(item["status"] == "error" for item in host_reports),
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
    return 0


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] not in {"once", "normalize"}:
        raise SystemExit("用法: sync_results.py once|normalize")
    if sys.argv[1] == "normalize":
        report = normalize_results()
        print(
            json.dumps(
                {
                    "selected_task_count": report["selected_task_count"],
                    "result_files_copied": report["result_files_copied"],
                    "progress_files_copied": report["progress_files_copied"],
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0
    return run_once()


if __name__ == "__main__":
    raise SystemExit(main())
