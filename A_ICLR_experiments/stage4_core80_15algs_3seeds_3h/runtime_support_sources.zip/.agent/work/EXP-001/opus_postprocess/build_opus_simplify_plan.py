from __future__ import annotations

import csv
import fcntl
import hashlib
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from AAAI_experiments.stage5_metric_calculation_0831.pipeline import clean_task_builder as builder
from AAAI_experiments.stage5_metric_calculation_0831.pipeline import dataset_probes
from AAAI_experiments.stage5_metric_calculation_0831.pipeline import ground_truth_extract


ROOT = Path(__file__).resolve().parents[4]
WORK = Path(__file__).resolve().parent
BATCH = "stage4_core80_all_20260922"
EVIDENCE = WORK / "evidence"
PLAN_DIR = WORK / "plans"
PLAN = PLAN_DIR / "simplify_core80.jsonl"
CONDITION_PLANS = {
    "clean": PLAN_DIR / "simplify_core80_clean.jsonl",
    "noise001": PLAN_DIR / "simplify_core80_noise001.jsonl",
    "noise005": PLAN_DIR / "simplify_core80_noise005.jsonl",
}
REPORT = PLAN_DIR / "simplify_core80.report.json"
UNRESOLVED = PLAN_DIR / "simplify_core80.unresolved.jsonl"
LOCK = WORK / ".plan.lock"
SOURCE_CSV = ROOT / ".agent/work/EXP-001/controller/core80_source.csv"
LOCAL_EXPERIMENTS = ROOT / "A_ICLR_experiments/stage4_core80_15algs_3seeds_3h/2、experiments"
MANIFEST = EVIDENCE / "core80_ground_truth.csv"
PROBES = EVIDENCE / "dataset_probes.jsonl"
PROBE_SUMMARY = EVIDENCE / "dataset_probes.summary.json"
GROUND_TRUTH = EVIDENCE / "ground_truth.jsonl"
GROUND_TRUTH_REPORT = EVIDENCE / "ground_truth.report.json"
PROMPT_CONTRACT = builder._load_prompt_schema(ROOT)
TASK_RE = re.compile(r"^(?P<algorithm>[a-z0-9]+)_s(?P<seed>520|521|522)_(?P<condition>clean|noise001|noise005)_g(?P<index>\d{4})$")
MAX_PREDICTION_AST_NODES_FOR_OPUS = 1000


def canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def source_rows() -> dict[int, dict[str, str]]:
    with SOURCE_CSV.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    return {int(row["global_index"]): row for row in rows}


def build_manifest(rows: dict[int, dict[str, str]]) -> None:
    fieldnames = [
        "core50_index",
        "dataset_name",
        "basename",
        "target_name",
        "feature_count",
        "metadata_yaml",
        "metadata_yaml_sha256",
        "formula_py",
        "formula_py_sha256",
        "train_csv",
        "train_csv_sha256",
        "valid_csv",
        "valid_csv_sha256",
        "id_test_csv",
        "id_test_csv_sha256",
        "ood_test_csv",
        "ood_test_csv_sha256",
        "dataset_dir",
    ]
    output_rows: list[dict[str, object]] = []
    for index in sorted(rows):
        row = rows[index]
        dataset_dir = ROOT / row["dataset_rel"]
        paths = {
            "metadata_yaml": dataset_dir / "metadata.yaml",
            "formula_py": dataset_dir / "formula.py",
            "train_csv": dataset_dir / "train.csv",
            "valid_csv": dataset_dir / "valid.csv",
            "id_test_csv": dataset_dir / "id_test.csv",
            "ood_test_csv": dataset_dir / "ood_test.csv",
        }
        for path in paths.values():
            if not path.is_file():
                raise FileNotFoundError(path)
        record: dict[str, object] = {
            "core50_index": index,
            "dataset_name": row["dataset_name"],
            "basename": row["dataset_name"],
            "target_name": row["target_name"],
            "feature_count": int(row["feature_count"]),
            "dataset_dir": row["dataset_rel"],
        }
        for field, path in paths.items():
            record[field] = str(path.relative_to(ROOT))
            record[f"{field}_sha256"] = sha256_file(path)
        output_rows.append(record)
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    import io

    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    writer.writerows(output_rows)
    atomic_write(MANIFEST, buffer.getvalue())


def ensure_inputs(rows: dict[int, dict[str, str]]) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    build_manifest(rows)
    manifest_sha256 = sha256_file(MANIFEST)
    cached_probe_summary: dict[str, Any] = {}
    cached_gt_report: dict[str, Any] = {}
    if PROBE_SUMMARY.is_file():
        cached_probe_summary = json.loads(PROBE_SUMMARY.read_text(encoding="utf-8"))
    if GROUND_TRUTH_REPORT.is_file():
        cached_gt_report = json.loads(GROUND_TRUTH_REPORT.read_text(encoding="utf-8"))
    evidence_ready = (
        PROBES.is_file()
        and GROUND_TRUTH.is_file()
        and cached_probe_summary.get("manifest_sha256") == manifest_sha256
        and cached_gt_report.get("manifest_sha256") == manifest_sha256
    )
    if not evidence_ready:
        dataset_probes.build_dataset_probes(
            manifest_csv=MANIFEST,
            output_jsonl=PROBES,
            output_summary=PROBE_SUMMARY,
            sample_size_per_split=8,
        )
        gt_records, gt_report = ground_truth_extract.build_ground_truth_records(
            MANIFEST,
            repo_root=ROOT,
        )
        ground_truth_extract.write_jsonl(GROUND_TRUTH, gt_records)
        ground_truth_extract.write_json(GROUND_TRUTH_REPORT, gt_report)
    else:
        gt_records = [
            json.loads(line)
            for line in GROUND_TRUTH.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
    probes, _ = builder.load_dataset_probes(PROBES)
    return (
        {str(row["dataset_id"]): row for row in gt_records},
        probes,
    )


def make_gt_task(row: dict[str, Any], probe: dict[str, Any]) -> dict[str, Any]:
    expression = str(row["normalized_expression_input"])
    variables = list(row["ordered_variables"])
    allowed, assumptions, deterministic = builder._build_symbolic_request_evidence(
        expression=expression,
        variables=variables,
        probe=probe,
    )
    evidence_hash = sha256_text(
        canonical_json(
            {
                "ground_truth_source_evidence_sha256": row["evidence_sha256"],
                "deterministic_evidence": deterministic,
            }
        )
    )
    request = {
        "dataset_id": row["dataset_id"],
        "target_name": row["target"],
        "variables": variables,
        "allowed_functions": allowed,
        "expression": expression,
        "original_expression": expression,
        "domain_assumptions": assumptions,
        "probe_points": probe["points"],
        "probe_source": probe["schema_version"],
        "probe_sample_sha256": probe["sample_sha256"],
        "dataset_probe_evidence": probe,
        "deterministic_evidence": deterministic,
        "ast_source_evidence": {
            "return_ast_dump": row["return_ast_dump"],
            "return_source": row["return_source"],
            "selection_reason": row["selection_reason"],
            "source_checksums": row["source_checksums"],
            "ground_truth_source_evidence_sha256": row["evidence_sha256"],
            "normalized_expression_input": expression,
            "raw_return_source": row["return_source"],
        },
        "evidence_hash": evidence_hash,
    }
    task = builder._build_task_definition(
        logical_id=f"gt_simplify::{row['dataset_id']}::core80",
        task_type=builder.GT_TASK_TYPE,
        priority=builder.GT_PRIORITY,
        request=request,
        evidence_hash=evidence_hash,
        contract=PROMPT_CONTRACT,
        condition="clean",
    )
    return task.to_json_record()


def prediction_tasks(
    rows: dict[int, dict[str, str]],
    gt_records: dict[str, dict[str, Any]],
    probes: dict[str, dict[str, Any]],
    result_paths: list[Path] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
    tasks: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    result_count = 0
    for result_path in sorted(result_paths if result_paths is not None else LOCAL_EXPERIMENTS.glob("*/*/*/*/result.json")):
        result_count += 1
        algorithm = result_path.parts[-5].lower()
        dataset_name = result_path.parts[-4]
        condition = result_path.parts[-3]
        seed = int(result_path.parts[-2])
        source_row = next((row for row in rows.values() if row["dataset_name"] == dataset_name), None)
        if source_row is None:
            unresolved.append({"path": str(result_path), "reason": "dataset_not_in_core80"})
            continue
        try:
            payload = json.loads(result_path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("result_not_object")
            expression_before_mapping = builder.canonical_expression(payload)
            if not expression_before_mapping:
                raise ValueError("missing_native_expression")
            feature_names = payload.get("feature_names")
            if not isinstance(feature_names, list) or not all(isinstance(item, str) for item in feature_names):
                raise ValueError("invalid_feature_names")
            if feature_names != list(probes[dataset_name]["variables"]):
                raise ValueError("feature_names_mismatch")
            expression, variable_mapping = builder.map_indexed_variables(
                expression_before_mapping,
                feature_names,
            )
            probe = probes[dataset_name]
            allowed, assumptions, deterministic = builder._build_symbolic_request_evidence(
                expression=expression,
                variables=feature_names,
                probe=probe,
            )
            result_sha256 = sha256_file(result_path)
            provenance_data: dict[str, Any] = {}
            provenance_path = result_path.parent / "provenance.json"
            if provenance_path.is_file():
                provenance_payload = json.loads(provenance_path.read_text(encoding="utf-8"))
                if isinstance(provenance_payload, dict):
                    provenance_data = provenance_payload
            artifact_raw = payload.get("canonical_artifact")
            if not isinstance(artifact_raw, dict):
                artifact_raw = {}
            ast_node_count = artifact_raw.get("ast_node_count")
            if (
                isinstance(ast_node_count, int)
                and ast_node_count > MAX_PREDICTION_AST_NODES_FOR_OPUS
            ):
                unresolved.append(
                    {
                        "path": str(result_path),
                        "reason": "prediction_ast_too_large_for_opus_simplify",
                        "ast_node_count": ast_node_count,
                        "max_ast_node_count": MAX_PREDICTION_AST_NODES_FOR_OPUS,
                    }
                )
                continue
            artifact = {
                key: artifact_raw.get(key)
                for key in (
                    "instantiated_expression",
                    "normalized_expression",
                    "return_expression_source",
                    "raw_equation",
                    "raw_equation_kind",
                    "python_function_source",
                    "variables",
                    "ast_node_count",
                    "tree_depth",
                    "normalization_mode",
                    "normalization_notes",
                )
            }
            evidence_payload = {
                "source": {
                    "algorithm": algorithm,
                    "algorithm_slug": algorithm,
                    "batch": BATCH,
                    "dataset_id": dataset_name,
                    "dataset_index": f"g{int(source_row['global_index']):04d}",
                    "host": provenance_data.get("source_host"),
                    "noise_tag": condition,
                    "path": str(result_path.resolve()),
                    "seed": seed,
                    "task_id": f"{algorithm}_s{seed}_{condition}_g{int(source_row['global_index']):04d}",
                    "result_sha256": result_sha256,
                },
                "result": {
                    "raw_sha256": result_sha256,
                    "status": payload.get("status"),
                    "equation": payload.get("equation"),
                    "selected_expression": expression_before_mapping,
                    "semantic_expression": expression,
                    "feature_names": feature_names,
                    "variable_mapping": variable_mapping,
                    "canonical_artifact": artifact,
                    "deterministic_symbolic_evidence": deterministic,
                },
            }
            evidence_hash = sha256_text(canonical_json(evidence_payload))
            request = {
                "dataset_id": dataset_name,
                "dataset_index": f"g{int(source_row['global_index']):04d}",
                "algorithm": algorithm,
                "algorithm_slug": algorithm,
                "seed": seed,
                "noise_tag": condition,
                "task_id": f"{algorithm}_s{seed}_{condition}_g{int(source_row['global_index']):04d}",
                "target_name": payload.get("target_name"),
                "variables": feature_names,
                "allowed_functions": allowed,
                "expression": expression,
                "original_expression": expression,
                "domain_assumptions": assumptions,
                "probe_points": probe["points"],
                "probe_source": probe["schema_version"],
                "probe_sample_sha256": probe["sample_sha256"],
                "dataset_probe_evidence": probe,
                "deterministic_evidence": deterministic,
                "ast_source_evidence": {
                    "selected_expression_source": "canonical_expression",
                    "selected_expression_before_variable_mapping": expression_before_mapping,
                    "semantic_expression_after_variable_mapping": expression,
                    "feature_names": feature_names,
                    "variable_mapping": variable_mapping,
                    "formula_candidates": {
                        "instantiated_expression": artifact.get("instantiated_expression"),
                        "normalized_expression": artifact.get("normalized_expression"),
                        "return_expression_source": artifact.get("return_expression_source"),
                        "equation": payload.get("equation"),
                    },
                    "canonical_artifact": artifact,
                    "result_status": payload.get("status"),
                    "result_path": str(result_path.resolve()),
                    "result_raw_sha256": result_sha256,
                },
                "evidence_hash": evidence_hash,
            }
            task = builder._build_task_definition(
                logical_id=(
                    f"pred_simplify::{algorithm}::g{int(source_row['global_index']):04d}"
                    f"::s{seed}::{condition}"
                ),
                task_type=builder.PRED_TASK_TYPE,
                priority=builder.PRED_PRIORITY,
                request=request,
                evidence_hash=evidence_hash,
                contract=PROMPT_CONTRACT,
                condition=condition,
            )
            tasks.append(task.to_json_record())
        except (KeyError, OSError, UnicodeError, json.JSONDecodeError, TypeError, ValueError) as exc:
            unresolved.append({"path": str(result_path), "reason": f"{type(exc).__name__}: {exc}"})
    return tasks, unresolved, result_count


def build_plan() -> int:
    WORK.mkdir(parents=True, exist_ok=True)
    with LOCK.open("w", encoding="utf-8") as lock_handle:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return 0
        rows = source_rows()
        gt_records, probes = ensure_inputs(rows)
        tasks = [make_gt_task(row, probes[row["dataset_id"]]) for row in gt_records.values()]
        pred_tasks, unresolved, result_count = prediction_tasks(rows, gt_records, probes)
        tasks.extend(pred_tasks)
        tasks.sort(key=lambda row: (int(row["priority"]), str(row["logical_id"])))
        plan_text = "".join(canonical_json(row) + "\n" for row in tasks)
        atomic_write(PLAN, plan_text)
        condition_plan_sha256: dict[str, str] = {}
        for condition, condition_path in CONDITION_PLANS.items():
            condition_tasks = [
                row
                for row in tasks
                if row["condition"] == condition
                and row["task_type"] == builder.PRED_TASK_TYPE
            ]
            condition_text = "".join(canonical_json(row) + "\n" for row in condition_tasks)
            atomic_write(condition_path, condition_text)
            condition_plan_sha256[condition] = sha256_text(condition_text)
        atomic_write(
            UNRESOLVED,
            "".join(canonical_json(row) + "\n" for row in unresolved),
        )
        report = {
            "schema_version": "stage4.opus_simplify_plan.v1",
            "built_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "core80_dataset_count": len(rows),
            "ground_truth_task_count": len(gt_records),
            "result_file_count": result_count,
            "prediction_task_count": len(pred_tasks),
            "unresolved_count": len(unresolved),
            "task_count": len(tasks),
            "plan_sha256": sha256_text(plan_text),
            "plan_path": str(PLAN.resolve()),
            "condition_plan_paths": {
                condition: str(path.resolve())
                for condition, path in CONDITION_PLANS.items()
            },
            "condition_plan_sha256": condition_plan_sha256,
            "unresolved_path": str(UNRESOLVED.resolve()),
            "prompt_path": PROMPT_CONTRACT.prompt_path,
            "prompt_sha256": PROMPT_CONTRACT.prompt_sha256,
            "schema_path": PROMPT_CONTRACT.schema_path,
            "schema_sha256": PROMPT_CONTRACT.schema_sha256,
        }
        atomic_write(REPORT, json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
        print(json.dumps(report, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(build_plan())
