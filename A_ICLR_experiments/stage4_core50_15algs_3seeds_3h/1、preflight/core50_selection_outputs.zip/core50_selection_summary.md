# Core-50 Selection Summary
This run applies the simplified generic Core-50 protocol without any SRSD-specific rule.

## Files checked
- `probe4_postprocess_run_level.csv`: present, 7968 rows
- `probe4_postprocess_dataset_algorithm.csv`: present, 2656 rows
- `probe4_postprocess_dataset_level.csv`: present, 664 rows
- `probe4_postprocess_summary.json`: present
- `selection_constraints_report.md`: present

## Core-50 metrics
- coverage: `0.7736`
- mean information score: `0.5308`
- mean discrimination score: `0.5904`
- mean stability score: `0.8997`
- Spearman / Kendall vs full-664 probe ranking: `1.0000` / `1.0000`
- aggregate score MAE vs full-664: `0.1388`

## Family distribution
| family                      |   selected |   quota_min |   quota_max |
|:----------------------------|-----------:|------------:|------------:|
| llm-srbench                 |         16 |          12 |          16 |
| srsd                        |         15 |          11 |          15 |
| srbench1.0                  |          9 |           7 |          11 |
| keijzer                     |          2 |           2 |           6 |
| srbench2025/firstprinciples |          2 |           2 |           6 |
| nguyen                      |          3 |           2 |           6 |
| korns                       |          2 |           2 |           6 |
| vladislavleva               |          1 |           1 |           5 |

## Difficulty distribution
| difficulty   |   selected |   min |   max |
|:-------------|-----------:|------:|------:|
| easy         |         10 |     4 |    10 |
| medium       |         23 |    14 |    24 |
| hard         |         12 |    12 |    22 |
| extreme      |          5 |     3 |     6 |

## Failure modes
| failure_mode    |   selected |
|:----------------|-----------:|
| all_good        |         20 |
| all_struggle    |          1 |
| one_method_wins |         11 |
| one_sided       |          1 |
| ood_failure     |         17 |
