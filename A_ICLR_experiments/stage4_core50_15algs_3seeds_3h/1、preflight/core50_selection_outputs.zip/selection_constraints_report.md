# Core-50 Selection Constraints Report
## Completeness check
- observed Probe4-Full runs: `7968`
- expected runs: `7968`
- dataset-level rows: `664`
- dataset × algorithm rows: `2656`
- run-level rows: `7968`
- missing required columns after postprocess: `[]` based on uploaded summary/report

## Selected Core-50 summary
- selected datasets: `50`
- objective: `0.7959`
- coverage: `0.7736`
- mean_info: `0.5308`
- mean_stability: `0.8997`
- aggregate score MAE vs full-664 probes: `0.1388`

## Family quotas
| family | full_count | target | min | max | selected | status |
|---|---:|---:|---:|---:|---:|---|
| llm-srbench | 240 | 13.34 | 12 | 16 | 16 | PASS |
| srsd | 232 | 12.98 | 11 | 15 | 15 | PASS |
| srbench1.0 | 133 | 8.51 | 7 | 11 | 9 | PASS |
| keijzer | 14 | 3.13 | 2 | 6 | 2 | PASS |
| srbench2025/firstprinciples | 12 | 3.04 | 2 | 6 | 2 | PASS |
| nguyen | 12 | 3.04 | 2 | 6 | 3 | PASS |
| korns | 12 | 3.04 | 2 | 6 | 2 | PASS |
| vladislavleva | 8 | 2.86 | 1 | 5 | 1 | PASS |

## Difficulty quotas
| difficulty | min | max | selected | status |
|---|---:|---:|---:|---|
| easy | 4 | 10 | 10 | PASS |
| medium | 14 | 24 | 23 | PASS |
| hard | 12 | 22 | 12 | PASS |
| extreme | 3 | 6 | 5 | PASS |

## Generic caps
| constraint | selected/value | threshold | status |
|---|---:|---:|---|
| semantic duplicate violations | 0 | 0 | PASS |
| basename violations | 0 | 0 | PASS |
| max subgroup count | 5 | 6 | PASS |
| limited_quota count | 6 | 8 | PASS |
| extreme count | 5 | 6 | PASS |
| one_sided count | 1 | 2 | PASS |
| unstable count | 0 | 5 | PASS |
| all_struggle count | 1 | 5 | PASS |
| max winner-probe count | 20 | 20 | PASS |

## Coverage anchors
- covered subgroups: `18` / `18`
- covered operator groups: `5` / `5`
- covered feature-count bins: `3` / `3`
- covered sample-count bins: `3` / `3`
- covered complexity bins: `3` / `3`

## Winner-probe balance
| probe | selected winner count | min | max | status |
|---|---:|---:|---:|---|
| dso | 9 | 3 | 20 | PASS |
| imcts | 18 | 3 | 20 | PASS |
| pyoperon | 3 | 3 | 20 | PASS |
| udsr | 20 | 3 | 20 | PASS |
