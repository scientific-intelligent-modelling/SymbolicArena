# Core-50 Rank-Fidelity Report
## Probe ranking
- full-664 ranking: `['udsr', 'imcts', 'dso', 'pyoperon']`
- Core-50 ranking: `['udsr', 'imcts', 'dso', 'pyoperon']`
- Spearman: `1.0000`
- Kendall: `1.0000`
- Pairwise win agreement: `1.0000`
- Weighted pairwise win agreement: `1.0000`
- Aggregate score MAE: `0.1388`
- Aggregate score normalized MAE: `0.0233`

## Full vs Core probe aggregate scores
| method | full-664 score | Core-50 score | delta |
|---|---:|---:|---:|
| dso | 2.4920 | 2.5166 | +0.0246 |
| imcts | 4.6086 | 4.5533 | -0.0553 |
| pyoperon | -0.2203 | -0.2752 | -0.0549 |
| udsr | 5.7395 | 6.1597 | +0.4202 |

## Baseline comparison
| label                               |       n |   objective |   coverage |   structural_coverage |   response_coverage |   mean_info |   mean_disc |   mean_stability |   balance |   spearman |   kendall |   pairwise_win_agreement |   weighted_pairwise_win_agreement |   aggregate_score_mae |   aggregate_score_nmae |   family_profile_jsd |   difficulty_profile_jsd |   failure_mode_profile_jsd |   operator_profile_jsd |   limited_count |   extreme_count |   duplicate_violations |   basename_violations |
|:------------------------------------|--------:|------------:|-----------:|----------------------:|--------------------:|------------:|------------:|-----------------:|----------:|-----------:|----------:|-------------------------:|----------------------------------:|----------------------:|-----------------------:|---------------------:|-------------------------:|---------------------------:|-----------------------:|----------------:|----------------:|-----------------------:|----------------------:|
| random-50_mean100                   | 50.0000 |      0.6157 |     0.7804 |                0.7384 |              0.8434 |      0.1949 |      0.3130 |           0.7070 |    0.9815 |     0.9880 |    0.9800 |                   0.9900 |                            0.9966 |                0.4949 |                 0.0830 |               0.0303 |                   0.0096 |                     0.0160 |                 0.0139 |          9.0500 |          5.1100 |                 0.0000 |                0.0000 |
| family-stratified-random-50_mean100 | 50.0000 |      0.6105 |     0.7772 |                0.7338 |              0.8423 |      0.1910 |      0.3097 |           0.6912 |    0.9695 |     0.9460 |    0.9100 |                   0.9550 |                            0.9847 |                0.5243 |                 0.0880 |               0.0557 |                   0.0088 |                     0.0176 |                 0.0373 |          9.6500 |          4.7500 |                 0.0000 |                0.0000 |
| metadata-diverse-50                 | 50.0000 |      0.6744 |     0.7712 |                0.7268 |              0.8379 |      0.3738 |      0.4462 |           0.8340 |    0.9824 |     1.0000 |    1.0000 |                   1.0000 |                            1.0000 |                0.5060 |                 0.0849 |               0.0233 |                   0.0008 |                     0.0162 |                 0.0445 |          8.0000 |          6.0000 |                 0.0000 |                0.0000 |
| response-kmedoids-50                | 50.0000 |      0.6342 |     0.7660 |                0.7391 |              0.8063 |      0.2726 |      0.4588 |           0.6258 |    0.9704 |     1.0000 |    1.0000 |                   1.0000 |                            1.0000 |                0.6044 |                 0.1014 |               0.0401 |                   0.0060 |                     0.0318 |                 0.0357 |          8.0000 |          3.0000 |                 0.0000 |                0.0000 |
| top-info-50                         | 50.0000 |      0.7305 |     0.7216 |                0.6931 |              0.7644 |      0.6049 |      0.6686 |           0.8931 |    0.9702 |     1.0000 |    1.0000 |                   1.0000 |                            1.0000 |                1.0339 |                 0.1735 |               0.0282 |                   0.0105 |                     0.0641 |                 0.0277 |          6.0000 |          6.0000 |                 0.0000 |                0.0000 |
| difficulty-balanced-50              | 50.0000 |      0.6957 |     0.7122 |                0.6723 |              0.7719 |      0.5145 |      0.5904 |           0.8375 |    0.9758 |     1.0000 |    1.0000 |                   1.0000 |                            1.0000 |                1.0430 |                 0.1750 |               0.0309 |                   0.0061 |                     0.0386 |                 0.0284 |          4.0000 |          4.0000 |                 0.0000 |                0.0000 |
| ours_core50                         | 50.0000 |      0.7284 |     0.7736 |                0.7536 |              0.8037 |      0.5308 |      0.5904 |           0.8997 |    0.9725 |     1.0000 |    1.0000 |                   1.0000 |                            1.0000 |                0.1388 |                 0.0233 |               0.0198 |                   0.0039 |                     0.0801 |                 0.0185 |          6.0000 |          5.0000 |                 0.0000 |                0.0000 |

## Decision
Core-50 passes rank-fidelity checks: Spearman/Kendall/pairwise agreement are 1.0, aggregate score MAE is lower than random and family-stratified random baselines, and no duplicate/basename violations are present.
