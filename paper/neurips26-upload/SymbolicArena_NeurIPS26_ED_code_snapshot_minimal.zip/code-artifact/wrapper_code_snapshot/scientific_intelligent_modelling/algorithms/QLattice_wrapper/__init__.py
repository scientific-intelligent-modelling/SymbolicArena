"""QLattice note"""

