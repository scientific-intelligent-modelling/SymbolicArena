# Core-50 ablation summary

| Selector | Objective | Coverage | Mean info | Mean stability | Aggregate-score MAE |
|---|---:|---:|---:|---:|---:|
| Random avg | 0.6157 | 0.7804 | 0.1949 | 0.7070 | 0.4949 |
| Family-random avg | 0.6105 | 0.7772 | 0.1910 | 0.6912 | 0.5243 |
| Metadata-diverse | 0.6744 | 0.7712 | 0.3738 | 0.8340 | 0.5060 |
| Response-space K-medoids | 0.6342 | 0.7660 | 0.2726 | 0.6258 | 0.6044 |
| Top-information | 0.7305 | 0.7216 | 0.6049 | 0.8931 | 1.0339 |
| Difficulty-balanced | 0.6957 | 0.7122 | 0.5145 | 0.8375 | 1.0430 |
| Core-50 | 0.7284 | 0.7736 | 0.5308 | 0.8997 | 0.1388 |
