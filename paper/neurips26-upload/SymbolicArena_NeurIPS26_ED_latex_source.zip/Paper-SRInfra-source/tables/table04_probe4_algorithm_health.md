# Candidate-200 health-gate audit for Probe-4 selection

The health gate is identity-agnostic. LLM-assisted methods are not manually excluded; in this calibration table they fail because their explosion rates exceed the threshold.

| Algorithm | Finite rate | Explosion rate | Gate result |
|:--|--:|--:|:--|
| DSO | 0.990 | 0.050 | pass |
| PyOperon | 0.975 | 0.035 | pass |
| iMCTS | 0.990 | 0.055 | pass |
| uDSR | 0.990 | 0.015 | pass |
| PySR | 0.985 | 0.205 | pass |
| QLattice | 0.950 | 0.030 | pass |
| TPSR | 0.975 | 0.250 | pass |
| gplearn | 1.000 | 0.140 | pass |
| LLM-SR | 1.000 | 0.365 | fail: explosion |
| DRSR | 1.000 | 0.355 | fail: explosion |
| E2ESR | 0.695 | 0.140 | fail: finite |
| RAG-SR | 0.885 | 0.585 | fail: finite/explosion |
