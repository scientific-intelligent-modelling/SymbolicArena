# Probe-4 selection audit

The final selected panel is DSO + iMCTS + PyOperon + uDSR. It is selected under a health-gated, identity-agnostic protocol. Relaxed rows are shown only as audit checks.

| Audit setting | Probe panel | Score | Decision |
|:--|:--|--:|:--|
| Health-gated rank 1 | DSO; PyOperon; QLattice; uDSR | 0.6570 | strict score optimum |
| **Health-gated rank 2** | **DSO; iMCTS; PyOperon; uDSR** | **0.6512** | **selected: near tie; adds MCTS/tree search** |
| Health-gated rank 3 | DSO; gplearn; iMCTS; uDSR | 0.6482 | close, but weaker evolutionary-GP coverage |
| Health-gated rank 4 | DSO; gplearn; PySR; TPSR | 0.6454 | high score, but no explicit MCTS probe |
| Health-gated rank 5 | DSO; gplearn; iMCTS; PySR | 0.6407 | lower panel fidelity than selected panel |
| Finite-only rank 7 | DRSR; gplearn; PySR; TPSR | 0.6374 | LLM-assisted panel enters only after Top-5 |
| Finite-only rank 9 | gplearn; LLM-SR; PySR; TPSR | 0.6191 | LLM-SR remains below health-gated alternatives |
| No health gate | E2ESR; PySR; QLattice; RAG-SR | 0.6817 | rejected: missing/explosion artifacts dominate |
