# Probe4-Full dataset labels, eligibility classes, and run outcomes.

| Category     | Label               |   Count |
|:-------------|:--------------------|--------:|
| Difficulty   | easy                |     133 |
| Difficulty   | extreme             |      67 |
| Difficulty   | hard                |     199 |
| Difficulty   | medium              |     265 |
| Eligibility  | eligible            |     540 |
| Eligibility  | limited_quota       |     124 |
| Failure mode | all_good            |     327 |
| Failure mode | all_struggle        |      33 |
| Failure mode | one_method_wins     |      83 |
| Failure mode | one_sided           |       3 |
| Failure mode | ood_failure         |     151 |
| Failure mode | unstable            |      67 |
| Run outcome  | partial_output      |     332 |
| Run outcome  | timeout_no_output   |      20 |
| Run outcome  | valid_extreme_error |     113 |
| Run outcome  | valid_finite_result |    7503 |
