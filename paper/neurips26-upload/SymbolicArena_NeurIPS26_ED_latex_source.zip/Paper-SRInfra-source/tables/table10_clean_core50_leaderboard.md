# Clean Core-50 leaderboard with numerical and symbolic diagnostics.

Methods are ranked by penalized OOD log NMSE over 50 datasets and five seeds. Lower ID/OOD log NMSE is better; higher SYM-F, exact-equivalence rate, and tree similarity are better.

|   Rank | Algorithm   |   Valid rate |   Metric complete rate |   Mean ID log NMSE |   Mean OOD log NMSE |   SYM-F |   Exact equiv % |   Tree similarity |
|-------:|:------------|-------------:|-----------------------:|-------------------:|--------------------:|--------:|----------------:|------------------:|
|      1 | uDSR        |        1.000 |                  1.000 |             -6.920 |              -5.646 |    36.8 |            24.0 |             0.129 |
|      2 | iMCTS       |        1.000 |                  0.968 |             -4.842 |              -3.960 |    41.5 |            30.8 |             0.185 |
|      3 | PySR        |        1.000 |                  0.960 |             -3.848 |              -3.055 |    43.6 |            34.0 |             0.242 |
|      4 | DSO         |        1.000 |                  0.972 |             -2.984 |              -2.458 |    31.3 |            18.0 |             0.183 |
|      5 | DRSR        |        1.000 |                  1.000 |             -3.396 |              -2.087 |    26.8 |            12.0 |             0.098 |
|      6 | LLM-SR      |        1.000 |                  0.992 |             -2.958 |              -1.420 |    27.3 |            12.8 |             0.102 |
|      7 | gplearn     |        1.000 |                  1.000 |             -2.013 |              -1.207 |    20.0 |             8.0 |             0.085 |
|      8 | QLattice    |        0.980 |                  0.972 |             -2.273 |              -0.780 |    17.8 |             4.8 |             0.029 |
|      9 | TPSR        |        1.000 |                  0.996 |              0.200 |               0.896 |    15.2 |             0.4 |             0.035 |
|     10 | PyOperon    |        0.984 |                  0.840 |             -0.070 |               1.079 |    11.3 |             0.0 |             0.026 |
|     11 | E2ESR       |        1.000 |                  0.800 |              2.049 |               2.891 |    12.4 |             0.0 |             0.001 |
|     12 | RAG-SR      |        1.000 |                  0.964 |              3.253 |               3.788 |    15.7 |             1.6 |             0.000 |
